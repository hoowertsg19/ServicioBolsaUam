package com.example.servicebolsa.repository;

import com.example.servicebolsa.model.Administrador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdministradorRepository extends JpaRepository<Administrador, Long> {
}
